var app=angular.module('myApp',["ngRoute"]);

app.config(function($rootProvider)
{
  $rootProvider

  .when("/", {
        templateUrl : "calculator.htm"
    })

});

app.controller('calculatorController',function($scope){

  $scope.numbers = {first_number : '',second_number : '',operation : ''};
  //$scope.operation = '';
  $scope.error_message = '' ;
  $scope.error_message1 = '' ;


  $scope.add = function()
  {
      console.log('errrrrrooorr11111');
    $scope.operation = 'addition';
    $scope.error_message = 'First number '+$scope.numbers.first_number;
    $scope.error_message1 = 'Second number '+$scope.numbers.second_number;



  };

});
