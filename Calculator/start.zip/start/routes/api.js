var express = require('express');
var router = express.Router();

router.route('/add')

  .post(function(req, res){

    var returnObj = {"data":0};
    var add_result = 0;
    var number1 = req.param("first_number");
    var number2 = req.param("second_number");

    console.log(number1);
    console.log(number2);


    returnObj.data = Number(number1) + Number(number2);
    console.log('*************');
    console.log(Number(add_result));


    return res.send(returnObj);
  });

  router.route('/subtract')

    .post(function(req, res){

      var returnObj = {"data":0};
      var add_result = 0;
      var number1 = req.param("first_number");
      var number2 = req.param("second_number");

      console.log(number1);
      console.log(number2);


      returnObj.data = Number(number1) - Number(number2);
      console.log('*************');
      console.log(Number(add_result));


      return res.send(returnObj);
    });

    router.route('/multiply')

      .post(function(req, res){

        var returnObj = {"data":0};
        var add_result = 0;
        var number1 = req.param("first_number");
        var number2 = req.param("second_number");

        console.log(number1);
        console.log(number2);


        returnObj.data = Number(number1) * Number(number2);
        console.log('*************');
        console.log(Number(add_result));


        return res.send(returnObj);
      });

      router.route('/divide')

        .post(function(req, res){

          var returnObj = {"data":0};
          var add_result = 0;
          var number1 = req.param("first_number");
          var number2 = req.param("second_number");

          console.log(number1);
          console.log(number2);


          returnObj.data = Number(number1) / Number(number2);
          console.log('*************');
          console.log(Number(add_result));


          return res.send(returnObj);
        });


module.exports = router;
