var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
	console.log('errrrrrooorr222222');
	res.render('calculator', { title: "calculator"});
});

module.exports = router;
